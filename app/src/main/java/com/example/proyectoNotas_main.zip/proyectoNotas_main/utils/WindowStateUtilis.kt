package com.example.proyectoNotas_main.utils

enum class NotasNavigationType {
    BOTTOM_NAVIGATION, NAVIGATION_RAIL, PERMANENT_NAVIGATION_DRAWER
}

enum class NotasContentType {
    LIST_ONLY,
    LIST_AND_DETAIL
}
