package com.example.proyectoNotas_main.viewModel

data class AppUiState (
    val cantidadNotas: Int=0,
    val cantidadTareas: Int=0,
    val cantidadTareasComp : Int=0
)